package com.example.finances.data.datasource.model

data class User(
    val id: String,
    val name: String,
    val age: Int,
    val address: String,
)
